import time
import requests
from datetime import datetime
import pytz  # Install with: pip install pytz
import time

def slow_print(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.05)
    print()

def sslow_print(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.02)
    print()

def ssslow_print(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.01)
    print()


def get_timezone(city):
    """Fetches the timezone for a given city."""
    try:
        timezone_api = f"https://nominatim.openstreetmap.org/search?city={city}&format=json"
        response = requests.get(timezone_api).json()
        
        if response:
            lat, lon = response[0]["lat"], response[0]["lon"]
            timezone_response = requests.get(f"https://api.timezonedb.com/v2.1/get-time-zone?key=your_api_key_here&format=json&by=position&lat={lat}&lng={lon}")
            timezone_data = timezone_response.json()
            
            return timezone_data["zoneName"]
        else:
            return "America/New_York"  # Default to Eastern Time if city not found
    except:
        return "America/New_York"  # Default fallback timezone

def get_weather(city):
    """Fetches the weather based on the user's city."""
    try:
        weather_api_key = "a504c0168cf4a56e89c4fc7bfef2f326"  # Replace with your OpenWeatherMap API key
        weather_url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={weather_api_key}&units=imperial"
        weather_data = requests.get(weather_url).json()

        temp = weather_data["main"]["temp"]
        description = weather_data["weather"][0]["description"]

        return f"The weather in {city} is {temp}°F with {description}."
    except:
        return "Sorry, dimrod."

def get_time(timezone):
    """Fetches the correct local time based on the user's timezone."""
    try:
        tz = pytz.timezone(timezone)
        now = datetime.now(tz)
        return f"The current time in {timezone} is {now.strftime('%I:%M %p')}."
    except:
        return "Sorry, I couldn't retrieve the time."

# Ask user for their location

city = input("Enter the city you are in: ").strip()
timezone = get_timezone(city)  # Get timezone based on user input


name = input("What is your name? ")
print('\033[K', end='\r')
sslow_print(" .              .")
sslow_print("  .            . ")
sslow_print("   .          .  ")
sslow_print("    .        .   ")
sslow_print("     .      .    ")
sslow_print("      .    .     ")
sslow_print("       .  .      ")
sslow_print("        ..       ")
sslow_print("        /\       ")
sslow_print("       /  \      ")
sslow_print("      / /\ \     ")
sslow_print("     / /  \ \    ")
sslow_print("    / /    \ \   ")
sslow_print("   / /      \ \  ")
sslow_print("  / /        \ \ ")
slow_print(" /_/  Bravo   \_\ ")

slow_print(f"Would you like to ask a question, {name}?")
start = input("Yes or No: ").lower()




def question_weather(question):
    question = question.lower()

    if "weather" in question:
        sslow_print(get_weather(city))
    elif "time" in question:
        sslow_print(get_time(timezone))
    elif "date" in question:
        today = datetime.now().strftime("%B %d, %Y")
        sslow_print(f"Today's date is {today}.")
    elif "help" in question:
        responses = [
            "| yooo you can ask about the weather, time, how are you, who are you       |",
            "| ...                                                                      |",
            "| you can leave using 'exit' in case you get bored                         |"
        ]
        for response in responses:
            sslow_print(response)
            time.sleep(1)
    elif "who are you" in question:
        responses = [
            "| huh?                                                      |",
            "| me?                                                       |",
            "| I'm BRAVO, a high school project by some idiot.          |",
            "| I answer basic questions that I can in this terminal.    |",
            "| Thanks for talking to me!                                |"
        ]
        for response in responses:
            sslow_print(response)
            time.sleep(1)
    elif "how are you" in question:
        sslow_print("| I'm good, done with the internet but good. |")
        sslow_print("| How are you? |")
        question_feeling = input("").lower()

        if "good" in question_feeling or "great" in question_feeling:
            sslow_print(f"| That's good, {name}. |")
            sslow_print("| Hopefully it stays that way! |")
        elif "bad" in question_feeling or "horrible" in question_feeling or "terrible" in question_feeling:
            sslow_print("| good                                 |")
            sslow_print("|I hope it stays that way              |")
            sslow_print("|hehehhehhhehhhehe                     |")
            sslow_print("|Kidding, I hope it gets better        |")
        else:
            sslow_print("| I hope your day ends on a high note! |")

    else:
        sslow_print("| Sorry, I don't know the answer to that. |")


        




if start == "yes":
    while True:  
        sslow_print("|What is your question?                                      |")
        question = input("")
        
        if question.lower() == "exit":
            ssslow_print("|Alright, see you soon " + name + "                                    |")
            ssslow_print(" \ \          / /          ")
            ssslow_print("  \ \        / /           ")
            ssslow_print("   \ \      / /            ")
            ssslow_print("    \ \    / /             ")
            ssslow_print("     \ \  / /              ")
            ssslow_print("      \ \/ /               ")
            ssslow_print("       \  /                ")
            ssslow_print("        \/                 ")
            ssslow_print("        ..                 ")
            ssslow_print("       .  .                ")
            ssslow_print("      .    .               ")
            ssslow_print("     .      .              ")
            ssslow_print("    .        .             ")
            ssslow_print("   .          .            ")
            ssslow_print("  .            .           ")
            ssslow_print(" .              .          ")
            break  
        
        question_weather(question)